#!/usr/bin/env bash
set -euo pipefail
umask 077
customer_bundle="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
python3 "$customer_bundle/install.py" --root /home/fasakha/public_html --release f4fce216692a0ca0bc4eee7c8f442276a940704d "$@"
