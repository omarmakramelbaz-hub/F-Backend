#!/usr/bin/env python3
"""Publish only the reviewed customer/address flow; preserve independent homepage edits."""
import argparse
from collections import Counter
import difflib
import fcntl
import hashlib
import json
import os
import pathlib
import pwd
import re
import stat
import subprocess
import tempfile

APP_ROOT = pathlib.Path('/home/fasakha/public_html')
BASELINE = 'b2ec35c91224af06bf1c8f9c2f0e54402f2291f9'
HOME = 'resources/views/site/home.blade.php'
ASSETS = ('public/storefront/storefront.css',)
EXACT_FILES = ASSETS
PUBLISH_ORDER = EXACT_FILES + (HOME,)
PHP = '/opt/cpanel/ea-php82/root/usr/bin/php'
BUNDLE_ROOT = pathlib.Path(__file__).resolve().parent
MAX_BYTES = 8 * 1024 * 1024


def blob(data):
    return hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()


def safe(path):
    for candidate in (path, *path.parents):
        if candidate.is_symlink():
            raise RuntimeError('SYMLINK_PATH: ' + str(path))


def safe_directories(path, uid):
    safe(path)
    for candidate in (path, *path.parents):
        meta = candidate.stat()
        if not stat.S_ISDIR(meta.st_mode) or meta.st_uid not in (0, uid) or meta.st_mode & 0o7022:
            raise RuntimeError('UNSAFE_DIRECTORY: ' + str(candidate))


def snapshot(path, uid):
    safe_directories(path.parent, uid)
    safe(path)
    if not path.exists():
        return None
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK)
    try:
        meta = os.fstat(fd)
        if (not stat.S_ISREG(meta.st_mode) or meta.st_uid not in (0, uid)
                or meta.st_mode & 0o7022 or meta.st_nlink != 1 or meta.st_size > MAX_BYTES):
            raise RuntimeError('UNSAFE_FILE: ' + str(path))
        with os.fdopen(fd, 'rb', closefd=False) as stream:
            payload = stream.read(MAX_BYTES + 1)
        after = os.fstat(fd)
        if len(payload) > MAX_BYTES or (meta.st_dev, meta.st_ino, meta.st_size, meta.st_mtime_ns, meta.st_ctime_ns) != (
                after.st_dev, after.st_ino, after.st_size, after.st_mtime_ns, after.st_ctime_ns):
            raise RuntimeError('CONCURRENT_EDIT: ' + str(path))
        return {'bytes': payload, 'uid': meta.st_uid, 'gid': meta.st_gid,
                'mode': stat.S_IMODE(meta.st_mode), 'device': meta.st_dev, 'inode': meta.st_ino,
                'mtime': meta.st_mtime_ns, 'ctime': meta.st_ctime_ns, 'links': meta.st_nlink}
    finally:
        os.close(fd)


def atomic(path, payload, previous, uid):
    safe_directories(path.parent, uid)
    safe(path)
    fd, temporary = tempfile.mkstemp(prefix='.web-customer-addresses-', dir=path.parent)
    try:
        with os.fdopen(fd, 'wb') as stream:
            stream.write(payload)
            stream.flush()
            os.fchmod(stream.fileno(), previous['mode'])
            os.fchown(stream.fileno(), previous['uid'], previous['gid'])
            os.fsync(stream.fileno())
        os.replace(temporary, path)
    finally:
        if os.path.exists(temporary):
            os.unlink(temporary)


def owned_command(root, arguments):
    result = subprocess.run(['runuser', '-u', 'fasakha', '--', *arguments],
                            cwd=root, capture_output=True, timeout=90)
    if result.returncode:
        # Application command output can contain private configuration; never print it.
        raise RuntimeError('APPLICATION_COMMAND_FAILED: ' + pathlib.Path(arguments[0]).name)
    return result.stdout


def source(root, revision, relative):
    if relative not in PUBLISH_ORDER or not re.fullmatch('[a-f0-9]{40}', revision):
        raise RuntimeError('SOURCE_NOT_REVIEWED')
    manifest_path = BUNDLE_ROOT / 'manifest.json'
    if manifest_path.exists():
        safe(manifest_path)
        if manifest_path.stat().st_size > 32768:
            raise RuntimeError('BUNDLE_MANIFEST_INVALID')
        manifest = json.loads(manifest_path.read_text())
        keys = {version + '/' + path for version in ('release', 'baseline') for path in PUBLISH_ORDER}
        if (not isinstance(manifest, dict) or set(manifest) != {'schema', 'release', 'baseline', 'blobs'}
                or manifest['schema'] != 1 or manifest['baseline'] != BASELINE
                or not isinstance(manifest['release'], str) or not re.fullmatch('[a-f0-9]{40}', manifest['release'])
                or manifest['release'] == BASELINE or not isinstance(manifest['blobs'], dict)
                or set(manifest['blobs']) != keys
                or any(not isinstance(value, str) or not re.fullmatch('[a-f0-9]{40}', value)
                       for value in manifest['blobs'].values())):
            raise RuntimeError('BUNDLE_MANIFEST_INVALID')
        versions = {manifest['release']: 'release', BASELINE: 'baseline'}
        if revision not in versions:
            raise RuntimeError('BUNDLE_REVISION_MISMATCH')
        key = versions[revision] + '/' + relative
        path = BUNDLE_ROOT / key
        safe(path)
        meta = path.stat()
        if not stat.S_ISREG(meta.st_mode) or meta.st_nlink != 1 or meta.st_size > MAX_BYTES:
            raise RuntimeError('BUNDLE_FILE_INVALID')
        payload = path.read_bytes()
        expected = manifest['blobs'][key]
    else:
        payload = owned_command(root, ['git', '-C', str(root), 'show', revision + ':' + relative])
        expected = owned_command(root, ['git', '-C', str(root), 'rev-parse', revision + ':' + relative]).decode().strip()
    if not re.fullmatch('[a-f0-9]{40}', expected) or len(payload) > MAX_BYTES or blob(payload) != expected:
        raise RuntimeError('SOURCE_BLOB_MISMATCH: ' + relative)
    return payload


def surgical_patch(current, baseline, reviewed, label=HOME):
    """Three-way token merge: retain independent live edits and refuse overlapping changes."""
    if current == reviewed:
        return current
    if baseline == reviewed:
        raise RuntimeError('RELEASE_CHANGE_MISSING: ' + label)
    # Recognize a completed patch beside independent SEO edits before diff token
    # alignment can choose another equivalent boundary for adjacent inserted tags.
    old_lines, new_lines, live_lines = [payload.splitlines(keepends=True)
                                        for payload in (baseline, reviewed, current)]
    old_counts, new_counts, live_counts = map(Counter, (old_lines, new_lines, live_lines))
    additions = new_counts - old_counts
    removals = old_counts - new_counts
    if (additions or removals) and all(live_counts[line] >= new_counts[line] for line in additions) and all(
            live_counts[line] <= new_counts[line] for line in removals):
        # Exact added lines must also occur in reviewed order, not merely as a bag.
        required = [line for line in new_lines if line in additions]
        at = 0
        for line in live_lines:
            if at < len(required) and line == required[at]:
                at += 1
        if at == len(required):
            return current
    # Attribute-level tokens avoid treating independent SEO additions and a nearby
    # asset cache version as one conflicting line replacement. Every byte is kept.
    old, new, live = [re.findall(rb'\s+|[^\s<>"=]+|.', payload, re.S)
                      for payload in (baseline, reviewed, current)]
    wanted = [op for op in difflib.SequenceMatcher(a=old, b=new, autojunk=False).get_opcodes() if op[0] != 'equal']
    live_ops = difflib.SequenceMatcher(a=old, b=live, autojunk=False).get_opcodes()
    changes = [op for op in live_ops if op[0] != 'equal']

    def overlap(a, b):
        _, a0, a1, _, _ = a
        _, b0, b1, _, _ = b
        if a0 == a1 and b0 == b1:
            return a0 == b0
        if a0 == a1:
            return b0 < a0 < b1
        if b0 == b1:
            return a0 < b0 < a1
        return max(a0, b0) < min(a1, b1)

    def offset(index, after_insert):
        for tag, a0, a1, b0, b1 in live_ops:
            if tag == 'insert' and a0 == index:
                return b1 if after_insert else b0
        for tag, a0, a1, b0, b1 in live_ops:
            if tag == 'equal' and a0 <= index <= a1:
                return b0 + index - a0
            if index == a0:
                return b0
            if index == a1:
                return b1
        raise RuntimeError('SOURCE_PATCH_CONFLICT: ' + label)

    patches = []
    for wanted_op in wanted:
        _, a0, a1, b0, b1 = wanted_op
        intersects = [op for op in changes if overlap(wanted_op, op)]
        if intersects:
            if len(intersects) == 1:
                _, l0, l1, j0, j1 = intersects[0]
                if (a0, a1) == (l0, l1) and new[b0:b1] == live[j0:j1]:
                    continue  # This exact change is already present beside independent edits.
            raise RuntimeError('SOURCE_PATCH_CONFLICT: ' + label)
        patches.append((offset(a0, True), offset(a1, False), new[b0:b1]))
    for start, end, lines in sorted(patches, key=lambda patch: (patch[0], patch[1]), reverse=True):
        live[start:end] = lines
    return b''.join(live)


def plan_target(root, release, relative, current):
    if relative not in PUBLISH_ORDER:
        raise RuntimeError('FILE_NOT_REVIEWED: ' + relative)
    if current is None:
        raise RuntimeError('STOREFRONT_FILE_MISSING: ' + relative)
    reviewed = source(root, release, relative)
    if current == reviewed:
        return current
    baseline = source(root, BASELINE, relative)
    if relative in EXACT_FILES:
        if current != baseline:
            raise RuntimeError('ASSET_SOURCE_CONFLICT: ' + relative)
        return reviewed
    return surgical_patch(current, baseline, reviewed, relative)


def backup_files(root, release, originals, targets):
    parent = root.parent / 'web-customer-address-backups'
    safe(parent)
    if parent.exists():
        meta = parent.stat()
        if not stat.S_ISDIR(meta.st_mode) or meta.st_uid != 0 or stat.S_IMODE(meta.st_mode) != 0o700:
            raise RuntimeError('BACKUP_PARENT_UNSAFE')
    else:
        parent.mkdir(mode=0o700)
    backup = pathlib.Path(tempfile.mkdtemp(prefix=release[:12] + '-', dir=parent))
    manifest = {'release': release, 'baseline': BASELINE, 'files': {},
                'target_blobs': {path: blob(payload) for path, payload in targets.items()}}
    for relative, previous in originals.items():
        manifest['files'][relative] = {key: value for key, value in previous.items() if key != 'bytes'}
        saved = backup / relative
        saved.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
        saved.write_bytes(previous['bytes'])
        saved.chmod(0o600)
    path = backup / 'manifest.json'
    path.write_text(json.dumps(manifest, indent=2))
    path.chmod(0o600)
    return backup


def _install_locked(root, release, check_only, uid):
    originals, targets = {}, {}
    for relative in PUBLISH_ORDER:
        previous = snapshot(root / relative, uid)
        targets[relative] = plan_target(root, release, relative, None if previous is None else previous['bytes'])
        originals[relative] = previous
    # Syntax-check the merged Blade source without booting the application.
    with tempfile.TemporaryDirectory(prefix='web-customer-addresses-lint-') as directory:
        os.chmod(directory, 0o755)
        for relative in (HOME,):
            candidate = pathlib.Path(directory) / pathlib.Path(relative).name
            candidate.write_bytes(targets[relative])
            candidate.chmod(0o644)
            owned_command(root, [PHP, '-l', str(candidate)])
    if check_only:
        print(json.dumps({'status': 'WEB_CUSTOMER_ADDRESSES_PREFLIGHT_OK', 'files': len(targets)}))
        return
    for relative, previous in originals.items():
        if snapshot(root / relative, uid) != previous:
            raise RuntimeError('CONCURRENT_EDIT: ' + relative)
    if all(originals[path]['bytes'] == targets[path] for path in PUBLISH_ORDER):
        print(json.dumps({'status': 'WEB_CUSTOMER_ADDRESSES_READY', 'updated_files': 0}))
        return
    backup = backup_files(root, release, originals, targets)
    written = {}
    try:
        for relative in PUBLISH_ORDER:
            previous = originals[relative]
            if snapshot(root / relative, uid) != previous:
                raise RuntimeError('CONCURRENT_EDIT: ' + relative)
            if previous['bytes'] != targets[relative]:
                atomic(root / relative, targets[relative], previous, uid)
                written[relative] = snapshot(root / relative, uid)
        for relative, published in written.items():
            if snapshot(root / relative, uid) != published:
                raise RuntimeError('CONCURRENT_EDIT: ' + relative)
        owned_command(root, [PHP, str(root / 'artisan'), 'view:clear'])
    except Exception as error:
        failures = []
        for relative, published in reversed(list(written.items())):
            try:
                if snapshot(root / relative, uid) != published:
                    raise RuntimeError('CONCURRENT_EDIT')
                atomic(root / relative, originals[relative]['bytes'], originals[relative], uid)
            except Exception:
                failures.append(relative)
        try:
            owned_command(root, [PHP, str(root / 'artisan'), 'view:clear'])
        except Exception:
            failures.append('compiled views')
        if failures:
            raise RuntimeError('ROLLBACK_INCOMPLETE: ' + ', '.join(failures) + '; backup=' + str(backup)) from error
        raise RuntimeError('WEB_CUSTOMER_ADDRESSES_ROLLED_BACK; backup=' + str(backup)) from error
    print(json.dumps({'status': 'WEB_CUSTOMER_ADDRESSES_READY', 'updated_files': len(written), 'backup': str(backup)}))


def install(root, release, check_only=False):
    if os.geteuid() != 0 or root != APP_ROOT or not re.fullmatch('[a-f0-9]{40}', release) or release == BASELINE:
        raise RuntimeError('FIXED_ROOT_RELEASE_REQUIRED')
    user = pwd.getpwnam('fasakha')
    safe_directories(root, user.pw_uid)
    if root.stat().st_uid != user.pw_uid:
        raise RuntimeError('APPLICATION_OWNER_REQUIRED')
    if check_only:
        return _install_locked(root, release, True, user.pw_uid)
    lock_path = root.parent / '.web-customer-address-update.lock'
    safe(lock_path)
    fd = os.open(lock_path, os.O_CREAT | os.O_RDWR | os.O_NOFOLLOW | os.O_NONBLOCK, 0o600)
    try:
        meta = os.fstat(fd)
        if (not stat.S_ISREG(meta.st_mode) or meta.st_uid != 0 or meta.st_nlink != 1
                or stat.S_IMODE(meta.st_mode) != 0o600):
            raise RuntimeError('UPDATE_LOCK_UNSAFE')
        fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
        return _install_locked(root, release, False, user.pw_uid)
    finally:
        os.close(fd)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--root', type=pathlib.Path, default=APP_ROOT)
    parser.add_argument('--release', required=True)
    parser.add_argument('--check', action='store_true')
    arguments = parser.parse_args()
    try:
        install(arguments.root, arguments.release, arguments.check)
    except Exception as error:
        print(json.dumps({'status': 'WEB_CUSTOMER_ADDRESSES_FAILED', 'reason': str(error)}))
        raise SystemExit(1)


if __name__ == '__main__':
    main()
