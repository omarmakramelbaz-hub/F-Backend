#!/usr/bin/env bash
set -euo pipefail
umask 077
customer_bundle="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
python3 "$customer_bundle/install.py" --root /home/fasakha/public_html --release b2ec35c91224af06bf1c8f9c2f0e54402f2291f9 "$@"
