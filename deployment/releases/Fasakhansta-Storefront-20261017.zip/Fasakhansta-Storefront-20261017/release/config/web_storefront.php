<?php
return [
    // Stores are discovered from the existing public Fasakhansta restaurant directory.
    // No static ID list: new public branches and stores appear automatically.
    'max_delivery_km'=>null,
];
