<?php
/** Deployment check: read-only menu/authorization checks; never creates a customer or order. */
require __DIR__.'/../vendor/autoload.php';
$app=require __DIR__.'/../bootstrap/app.php';
$app->make(\Illuminate\Contracts\Console\Kernel::class)->bootstrap();
try {
    $store=app(\App\Services\Site\WebStorefront::class);
    $branches=$store->branches();
    if (!$branches || !\Illuminate\Support\Facades\Schema::hasTable('web_storefront_orders')) throw new \RuntimeException;
    $products=0;
    foreach ($branches as $branch) $products+=count($store->catalog($branch['id'])['products']);
    if ($products<1) throw new \RuntimeException;
    if (!\Illuminate\Support\Facades\Route::has('storefront.checkout')) throw new \RuntimeException;
    if (!app(\App\Services\Dashboard\PosServiceTable::class)->ready()) throw new \RuntimeException;
    echo json_encode(['status'=>'WEB_STOREFRONT_RUNTIME_OK','branches'=>count($branches),'products'=>$products]).PHP_EOL;
} catch (\Throwable $error) {
    fwrite(STDERR,'WEB_STOREFRONT_RUNTIME_CHECK_FAILED'.PHP_EOL);
    exit(1);
}
