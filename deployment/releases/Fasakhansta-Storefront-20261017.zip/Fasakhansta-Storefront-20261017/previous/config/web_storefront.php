<?php
return [
    // Verified physical Fasakhansta branches, not all marketplace restaurants.
    'branch_ids'=>[94,301,307,363],
    'max_delivery_km'=>null,
];
