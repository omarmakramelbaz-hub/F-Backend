<?php

namespace App\Services\Site;

use App\Models\Resturant;
use App\Models\User;
use App\Services\GoServices\Money;
use App\Services\Dashboard\{BranchCustomers, PhoneDelivery, PhoneMapProvider, PosServiceTicket, TakeawayAccess, TakeawayCatalog};
use Illuminate\Contracts\Encryption\DecryptException;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\{Crypt, DB, Schema, Validator};

/** Public checkout exposes a narrow, session-bound command; never a dashboard login. */
class WebStorefront
{
    public function publicInfo(): array
    {
        $settings = app(\App\Models\GeneralSettings::class);
        return ['phone'=>(string)$settings->phone,'email'=>(string)$settings->email,
            'terms'=>trim(strip_tags(preg_replace('/<\/(?:p|div|li)>|<br\s*\/?\s*>/i',"\n",(string)$settings->terms_ar))),
            'policy'=>trim(strip_tags(preg_replace('/<\/(?:p|div|li)>|<br\s*\/?\s*>/i',"\n",(string)$settings->policy_ar)))];
    }

    public function branches(): array
    {
        $result = [];
        foreach (Resturant::withoutGlobalScopes()->whereIn('id', config('web_storefront.branch_ids', []))->orderBy('id')->get() as $branch) {
            if (!in_array($branch->status, ['opened', 'busy', 'closed'], true)) continue;
            $result[] = ['id'=>(int)$branch->id, 'name'=>(string)$branch->name, 'address'=>(string)$branch->address,
                'phone'=>(string)$branch->phone, 'open'=>$branch->effective_status === 'opened',
                'status'=>$branch->effective_status, 'latitude'=>is_numeric($branch->lat)?(float)$branch->lat:null,
                'longitude'=>is_numeric($branch->lng)?(float)$branch->lng:null];
        }
        return $result;
    }

    public function catalog(int $id): array
    {
        [$branch, $actor] = $this->branch($id);
        $catalog = app(TakeawayCatalog::class)->listing(['branch'=>'f:'.$id,'per_page'=>500,'page'=>1], $actor);
        // Cost, recipes, balances, internal actors and administrative permissions are private.
        $products = [];
        foreach ($catalog['items'] as $item) {
            if (!$item['available']) continue;
            $products[] = array_intersect_key($item, array_flip(['id','name','price','image_url','unit','quantity_mode','category_id','options']));
        }
        return ['products'=>$products, 'categories'=>$catalog['categories'], 'open'=>$branch->effective_status==='opened'];
    }

    public function suggestions(int $id, string $query): array
    {
        [, $actor] = $this->branch($id);
        return app(PhoneMapProvider::class)->suggestions(['branch'=>'f:'.$id,'query'=>$query], $actor);
    }

    public function quote(Request $request): array
    {
        $values = Validator::make($request->all(), [
            'branch_id'=>'required|integer|min:1', 'customer_name'=>'required|string|min:2|max:100',
            'customer_phone'=>'required|string|max:30', 'address'=>'required|string|min:8|max:500',
            'area'=>'required|string|min:2|max:150', 'notes'=>'nullable|string|max:350',
            'latitude'=>'required|numeric|between:22,32', 'longitude'=>'required|numeric|between:24,37',
            'location_confirmed'=>'required|accepted', 'items'=>'required|array|min:1|max:40',
            'items.*.product_id'=>'required|integer|min:1', 'items.*.quantity'=>['required','string','regex:/^(?:[1-9][0-9]?(?:\.[0-9]{1,3})?|0\.[0-9]{1,3})$/D'],
            'items.*.quantity_mode'=>'required|in:piece,weight', 'items.*.option_id'=>'nullable|string|max:80',
        ])->validate();
        $phone = BranchCustomers::phoneKey($values['customer_phone']);
        abort_unless(preg_match('/^01[0125][0-9]{8}$/D', $phone), 422, 'اكتب رقم موبايل مصري صحيحًا من ١١ رقمًا.');
        $values['customer_phone'] = $phone;
        foreach (['customer_name','address','area','notes'] as $key) $values[$key] = trim($values[$key] ?? '');
        abort_unless(mb_strlen($values['customer_name'])>=2 && mb_strlen($values['address'])>=8 && mb_strlen($values['area'])>=2,422,'أكمل الاسم والعنوان والمنطقة.');
        [$branch, $actor] = $this->branch((int)$values['branch_id'], true);
        $values['branch'] = 'f:'.$branch->id;
        // Strip all nested input except the four permitted cart fields.
        $values['items'] = array_map(fn($line)=>array_intersect_key($line,array_flip(['product_id','quantity','quantity_mode','option_id'])), $values['items']);
        $values['discount'] = '0.00';
        $delivery = app(PhoneDelivery::class)->quote($values, $actor)['delivery'];
        $radius = config('web_storefront.max_delivery_km');
        if (is_numeric($radius) && $radius > 0) abort_unless((int)$delivery['distance_meters'] <= (float)$radius*1000,422,'العنوان خارج نطاق توصيل الفرع. اختر فرعًا أقرب.');
        $values['delivery_quote_hash'] = $delivery['delivery_quote_hash'];
        $quote = app(PosServiceTicket::class)->quote('phone', $values, $actor);
        $minimum = is_numeric($branch->min_order_price) ? Money::minor((string)$branch->min_order_price) : 0;
        abort_unless($quote['subtotal_cents'] >= $minimum,422,'الحد الأدنى لمنتجات الطلب من الفرع '.Money::decimal($minimum).' جنيه.');
        abort_unless($quote['total_cents'] > 0 && $quote['total_cents'] <= 2000000,422,'إجمالي الطلب يجب أن يكون من ١ جنيه إلى ٢٠ ألف جنيه.');
        $values['quote_hash'] = $quote['quote_hash'];
        $sealed = ['v'=>1, 'session'=>$this->sessionHash($request), 'expires'=>time()+600, 'values'=>$values];
        return ['success'=>true,'token'=>Crypt::encryptString(json_encode($sealed,JSON_UNESCAPED_UNICODE)),
            'summary'=>$this->summary($quote), 'distance_km'=>$delivery['distance_km']];
    }

    public function checkout(Request $request): array
    {
        $v = Validator::make($request->all(), ['token'=>'required|string|max:32000','idempotency_key'=>'required|uuid'])->validate();
        abort_unless(Schema::hasTable('web_storefront_orders'),503,'استقبال طلبات الموقع غير متاح حاليًا.');
        try { $sealed = json_decode(Crypt::decryptString($v['token']), true, 64, JSON_THROW_ON_ERROR); }
        catch (DecryptException | \JsonException $error) { abort(422,'انتهت صلاحية مراجعة الطلب. راجع الإجمالي مرة أخرى.'); }
        abort_unless(is_array($sealed) && ($sealed['v']??null)===1 && isset($sealed['session'],$sealed['expires'],$sealed['values'])
            && hash_equals($this->sessionHash($request),$sealed['session']),403,'راجع الطلب في نفس المتصفح.');
        $session = $this->sessionHash($request);
        $hash = hash('sha256',$v['token']);
        return DB::transaction(function () use ($sealed,$v,$session,$hash) {
            // The branch row serializes retries across devices/processes. Replays stay valid after closing/expiry.
            [$branch,$actor] = $this->branch((int)$sealed['values']['branch_id'],false,true);
            $old = DB::table('web_storefront_orders')->where('session_hash',$session)->where(function($q) use ($v,$hash) { $q->where('request_key',$v['idempotency_key'])->orWhere('payload_hash',$hash); })->first();
            if ($old) {
                abort_unless(hash_equals($old->payload_hash,$hash),409,'رقم العملية مستخدم لطلب آخر.');
                return $this->confirmation((int)$old->ticket_id,(int)$branch->id);
            }
            abort_unless($sealed['expires']>=time(),409,'انتهت صلاحية السعر. راجع الإجمالي مرة أخرى.');
            abort_unless($branch->effective_status==='opened',409,'الفرع مغلق الآن. اختر فرعًا متاحًا.');
            $values = $sealed['values'];
            $values['idempotency_key'] = $this->commandKey($session,$v['idempotency_key']);
            $values['notes'] = 'طلب الموقع الإلكتروني'.($values['notes']!==''?' — '.$values['notes']:'');
            // An unpaid ticket appears in the branch delivery board. Staff accept and send it to the kitchen.
            $values['send_to_kitchen'] = false;
            $result = app(PosServiceTicket::class)->save('phone',$values,$actor);
            $ticket = (int)$result['ticket']['id'];
            DB::table('web_storefront_orders')->insert(['session_hash'=>$session,'request_key'=>$v['idempotency_key'],
                'payload_hash'=>$hash,'branch_id'=>(int)$branch->id,'ticket_id'=>$ticket,'created_at'=>now('UTC')]);
            return $this->confirmation($ticket,(int)$branch->id);
        },3);
    }

    protected function branch(int $id, bool $open=false, bool $lock=false): array
    {
        abort_unless(in_array($id, array_map('intval',config('web_storefront.branch_ids',[])),true),404);
        $query = Resturant::withoutGlobalScopes()->where('id',$id);
        if ($lock) $query->lockForUpdate();
        $branch = $query->first();
        abort_unless($branch && in_array($branch->status,['opened','busy','closed'],true),404);
        if ($open) abort_unless($branch->effective_status==='opened',409,'الفرع غير متاح لاستقبال طلبات الآن.');
        $actor = User::withoutGlobalScopes()->find($branch->user_id);
        // Only the branch's persisted operator, never an owner/global admin or visitor-provided actor.
        abort_unless($actor && ($actor->account_type==='vendor' || ($actor->account_type==='admin' && (int)$actor->owner_resturant_id===$id)),503,'الطلب من هذا الفرع غير متاح حاليًا.');
        app(TakeawayAccess::class)->branch('f:'.$id,$actor,$lock);
        return [$branch,$actor];
    }

    private function summary(array $quote): array
    {
        return array_intersect_key($quote,array_flip(['subtotal','tax','delivery','total'])) + ['items'=>array_map(fn($line)=>array_intersect_key($line,array_flip(['name','option_label','quantity','quantity_mode','unit_price','total'])), $quote['items'])];
    }

    private function confirmation(int $id,int $branch): array
    {
        $row = DB::table('pos_service_tickets')->where('id',$id)->where('branch','f:'.$branch)->first();
        abort_unless($row,503,'تعذر قراءة تأكيد الطلب.');
        return ['success'=>true,'order'=>['number'=>'WEB-'.$id,'status'=>$row->status,'total'=>json_decode($row->quote_snapshot,true)['total'],
            'payment'=>'cash_on_delivery','branch_id'=>$branch]];
    }

    private function sessionHash(Request $request): string { return hash_hmac('sha256',$request->session()->getId(),(string)config('app.key')); }
    private function commandKey(string $session,string $key): string
    {
        $hex = hash('sha256','web-storefront:'.$session.':'.$key);
        return substr($hex,0,8).'-'.substr($hex,8,4).'-4'.substr($hex,13,3).'-a'.substr($hex,17,3).'-'.substr($hex,20,12);
    }
}
