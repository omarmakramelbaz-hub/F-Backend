# Fasakhansta web storefront

The homepage now provides an Arabic storefront with branch selection, current branch products and prices, product options, weight or unit quantities, a cart, a delivery pin, a server-priced review and cash-on-delivery confirmation. The app's existing catalog remains authoritative. No menu items or prices are changed by this release.

Website orders are created as **new, unpaid phone-channel tickets** in the selected branch's existing delivery board, marked `طلب الموقع الإلكتروني`. Branch staff accept and send them to the kitchen using their existing workflow. Checkout never collects cash or marks an order paid. Customer details remain in the native ticket and the existing customers/history workflow.

All public Fasakhansta restaurants and stores are discovered dynamically from existing status and application-scope rules. Physical branches and regional stores are grouped in the selector, with a searchable directory. Hidden/private and GO catalogs are excluded. The server derives the operator from the selected restaurant relationship and refuses owners/global administrators. No dashboard cookie, visitor-selected operator, public customer search, discount, manual delivery override, ticket editing or register operation is exposed. Official business contact/terms/privacy text come from existing public settings.

The review token is encrypted, bound to the visitor's session, and expires after ten minutes. Checkout revalidates the branch, catalog, native price fingerprint and delivery fingerprint. A dedicated additive table enforces one result per review token or request key. Retrying an uncertain request preserves the same token/key and returns the existing result, including when a branch has subsequently closed. Changing price or address requires another review. The existing branch minimum order is respected. `config/web_storefront.php` can optionally set a delivery radius; null preserves the native delivery calculation without introducing a new radius policy.

## Deployment

Use `deployment/apply_web_storefront_root.sh FULL_RELEASE_SHA` as root on `/home/fasakha/public_html`. `--check` performs the read-only source/permission/patch preflight. The installer verifies source blobs, merges only the reviewed homepage route change, backs up affected live files, publishes the isolated new assets/classes, runs only the new mapping-table migration, clears the necessary caches and checks branch catalogs and POS readiness. Conflicting source edits are refused. Failed application checks restore files without dropping business data. Existing POS, messaging, CRM and sidebar files are preserved.

Success marker: `WEB_STOREFRONT_READY`. Runtime check: `deployment/check_web_storefront.php`. The public homepage and `/shop/*` endpoints stay on the existing domain; the private static design preview is separate and cannot submit live orders.

## Validation

- `WEB_STORE_TEST_VENDOR=/path/to/laravel8/vendor php tests/web_storefront_runtime.php`: real Laravel 8/SQLite native pricing and unpaid ticket tests, dynamic store discovery and isolation, cross-branch/hidden products, changed prices, invalid quantities, session binding, tampering, idempotency, and no cash/print side effects.
- `python3 tests/web_storefront_installer_test.py`: route merge preserves unrelated source, conflicting edits fail, release scope and assets exist.
- `WEB_STORE_DOM_MODULE=/path/to/jsdom node tests/web_storefront_ui_test.cjs /path/to/rendered-home.html`: catalog rendering, safe text, fractional weights, branch-change confirmation, review, double-click prevention, stable retries and success.
- Production Blade compiles; section anchors and IDs validate; PHP, JavaScript and deployment shell syntax checks pass.
- Browser visual QA was unavailable in the managed environment. No production customer order was submitted.

Hero image: built-in image generation; prompt requested premium editorial Egyptian feseekh and smoked herring fillets with lemon, onion, chili, tahini and baladi bread on a navy tabletop matching dashboard #091320 and orange #FD7201, with no text/logo. Stored as `public/storefront/hero.webp`. It is explicitly captioned as a presentation image. Product cards use their original catalog images.

The 2026-10-17 palette/store update uses the dashboard navy #091320 and orange #FD7201 throughout. A navy version of the existing hero photograph preserves the food and arrangement. The preview snapshot now covers all 32 public Fasakhansta stores/branches observed at preparation time.
