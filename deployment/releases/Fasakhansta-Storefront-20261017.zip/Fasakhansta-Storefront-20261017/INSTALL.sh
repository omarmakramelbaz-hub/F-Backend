#!/usr/bin/env bash
set -euo pipefail
storefront_bundle="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
python3 "$storefront_bundle/install.py" --root /home/fasakha/public_html --release 1aa34ec649d974926c7e5f9b9c3b3489e1912031 "$@"
