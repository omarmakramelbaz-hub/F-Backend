#!/usr/bin/env python3
"""Publish crawlable storefront pages without changing customer data or order handling."""
import argparse
import difflib
import fcntl
import hashlib
import json
import os
import pathlib
import pwd
import re
import stat
import subprocess
import tempfile

APP_ROOT = pathlib.Path('/home/fasakha/public_html')
BASELINE = '01b8805ef49cc05c315edbde7909ad6489954190'
BASELINES = dict.fromkeys(('routes/web.php', 'resources/views/site/home.blade.php'), BASELINE)
# Kept explicit: the installer never traverses an application tree or publishes unrelated files.
NEW_FILES = (
    'app/Http/Controllers/Site/StorefrontSeoController.php',
    'app/Services/Site/StorefrontSeo.php',
    'routes/web_storefront_seo.php',
    'resources/views/site/seo/head.blade.php',
    'resources/views/site/seo/layout.blade.php',
    'resources/views/site/seo/cards.blade.php',
    'resources/views/site/seo/home-products.blade.php',
    'resources/views/site/seo/index.blade.php',
    'resources/views/site/seo/category.blade.php',
    'public/storefront/seo.css',
    'deployment/check_web_storefront_seo.php',
)
ROBOTS = 'public/robots.txt'
LOGIN = 'resources/views/admin/login.blade.php'
LOGIN_START = b'<!-- FASAKHANSTA SEO AUTH NOINDEX START -->'
LOGIN_END = b'<!-- FASAKHANSTA SEO AUTH NOINDEX END -->'
LOGIN_BLOCK = LOGIN_START + b'\n    <meta name="robots" content="noindex, nofollow">\n    ' + LOGIN_END
SITEMAP_LINE = b'Sitemap: https://fasakhaninja.com/sitemap.xml'
PUBLISH_ORDER = NEW_FILES + tuple(BASELINES) + (ROBOTS, LOGIN)
PHP = '/opt/cpanel/ea-php82/root/usr/bin/php'


def blob(data):
    return hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()


def matches(lines, block, at_start=False, at_end=False):
    size = len(block)
    return [i for i in range(len(lines) - size + 1)
            if block and (not at_start or i == 0) and (not at_end or i + size == len(lines))
            and lines[i:i + size] == block]


def surgical_patch(current, baseline, reviewed, label):
    """Merge uniquely anchored reviewed hunks while preserving independent live edits."""
    if baseline == reviewed:
        raise RuntimeError('RELEASE_CHANGE_MISSING: ' + label)
    if current == reviewed:
        return current
    old, new, live = [content.splitlines(keepends=True) for content in (baseline, reviewed, current)]
    for group in difflib.SequenceMatcher(a=old, b=new, autojunk=False).get_grouped_opcodes(8):
        a0, a1 = group[0][1], group[-1][2]
        b0, b1 = group[0][3], group[-1][4]
        before, after = old[a0:a1], new[b0:b1]
        start, end = a0 == 0, a1 == len(old)
        pre, post = matches(live, before, start, end), matches(live, after, start, end)
        if len(post) == 1 and (not pre or (len(pre) == 1 and len(after) > len(before)
                and post[0] <= pre[0] and pre[0] + len(before) <= post[0] + len(after))):
            continue
        if len(pre) == 1 and (not post or (len(post) == 1 and len(before) > len(after)
                and pre[0] <= post[0] and post[0] + len(after) <= pre[0] + len(before))):
            live[pre[0]:pre[0] + len(before)] = after
            continue
        raise RuntimeError('SOURCE_PATCH_CONFLICT: ' + label)
    return b''.join(live)


def robots_patch(current, reviewed):
    """Append one stable sitemap without changing existing robots directives."""
    lines = reviewed.splitlines()
    if lines.count(SITEMAP_LINE) != 1:
        raise RuntimeError('SITEMAP_DIRECTIVE_MISSING')
    if current is None:
        return reviewed
    existing = [line.strip() for line in current.splitlines()]
    if SITEMAP_LINE in existing:
        return current
    # A different URL can represent an independently maintained sitemap. Preserve it.
    newline = b'\r\n' if b'\r\n' in current else b'\n'
    return current + (b'' if not current or current.endswith(b'\n') else newline) + SITEMAP_LINE + newline


def login_patch(current, reviewed):
    """Add an authentication indexing instruction without replacing concurrent logo or login edits."""
    if LOGIN_BLOCK not in reviewed or reviewed.count(LOGIN_START) != 1 or reviewed.count(LOGIN_END) != 1:
        raise RuntimeError('AUTH_NOINDEX_RELEASE_INVALID')
    if current is None:
        raise RuntimeError('BASELINE_FILE_MISSING: ' + LOGIN)
    heads = list(re.finditer(br'<head(?:\s[^>]*)?>', current, re.I))
    closes = list(re.finditer(br'</head\s*>', current, re.I))
    if len(heads) != 1 or len(closes) != 1 or heads[0].end() >= closes[0].start():
        raise RuntimeError('AUTH_NOINDEX_HEAD_AMBIGUOUS')
    start, end = heads[0].end(), closes[0].start()
    head = current[start:end]
    charset = b'<meta charset="utf-8">'
    charset_tags, robots_tags = [], []
    for tag in re.findall(br'<meta\b[^>]*>', head, re.I):
        attributes = {}
        for match in re.finditer(br'([\w:-]+)\s*=\s*(?:"([^"]*)"|\'([^\']*)\'|([^\s>]+))', tag):
            key = match.group(1).lower()
            if key in attributes:
                raise RuntimeError('AUTH_NOINDEX_META_AMBIGUOUS')
            attributes[key] = next(group for group in match.groups()[1:] if group is not None).lower()
        if b'charset' in attributes:
            charset_tags.append(tag)
        if attributes.get(b'name') == b'robots':
            robots_tags.append(attributes)
    if charset_tags != [charset] or head.count(charset) != 1:
        raise RuntimeError('AUTH_NOINDEX_CHARSET_AMBIGUOUS')
    if len(robots_tags) > 1:
        raise RuntimeError('AUTH_NOINDEX_ROBOTS_AMBIGUOUS')
    if robots_tags:
        tokens = set(re.split(br'[,\s]+', robots_tags[0].get(b'content', b'')))
        if b'noindex' not in tokens or b'index' in tokens or b'all' in tokens:
            raise RuntimeError('AUTH_NOINDEX_ROBOTS_CONFLICT')
    if LOGIN_START in current or LOGIN_END in current:
        if current.count(LOGIN_START) != 1 or current.count(LOGIN_END) != 1 or head.count(LOGIN_BLOCK) != 1 or not robots_tags:
            raise RuntimeError('AUTH_NOINDEX_MARKER_CONFLICT')
        return current
    if robots_tags:
        return current
    amended = head.replace(charset, charset + b'\n    ' + LOGIN_BLOCK, 1)
    return current[:start] + amended + current[end:]


def safe(path):
    for candidate in (path, *path.parents):
        if candidate.is_symlink():
            raise RuntimeError('SYMLINK_PATH: ' + str(path))


def snapshot(path, uid):
    safe(path)
    if not path.exists():
        return None
    meta = path.stat()
    if not stat.S_ISREG(meta.st_mode) or meta.st_uid not in (0, uid) or meta.st_mode & 0o7022 or meta.st_nlink != 1:
        raise RuntimeError('UNSAFE_FILE: ' + str(path))
    return {'bytes': path.read_bytes(), 'uid': meta.st_uid, 'gid': meta.st_gid,
            'mode': stat.S_IMODE(meta.st_mode), 'device': meta.st_dev, 'inode': meta.st_ino,
            'mtime': meta.st_mtime_ns, 'links': meta.st_nlink}


def safe_directory(path, uid):
    """All existing application ancestors must be directories owned by root or the site account."""
    safe(path)
    for candidate in (path, *path.parents):
        if not candidate.exists():
            continue
        meta = candidate.stat()
        trusted_gid = pwd.getpwuid(uid).pw_gid
        if (not stat.S_ISDIR(meta.st_mode) or meta.st_uid not in (0, uid) or meta.st_mode & 0o4002
                or (meta.st_mode & 0o2020 and meta.st_gid not in (0, trusted_gid))):
            raise RuntimeError('UNSAFE_DIRECTORY: ' + str(candidate))


def atomic(path, data, mode, uid, gid):
    safe(path)
    if not path.parent.is_dir():
        raise RuntimeError('PARENT_DIRECTORY_MISSING: ' + str(path.parent))
    fd, temporary = tempfile.mkstemp(prefix='.web-storefront-seo-', dir=path.parent)
    try:
        with os.fdopen(fd, 'wb') as stream:
            stream.write(data)
            stream.flush()
            os.fsync(stream.fileno())
        os.chmod(temporary, mode)
        os.chown(temporary, uid, gid)
        os.replace(temporary, path)
    finally:
        if os.path.exists(temporary):
            os.unlink(temporary)


def owned_command(root, arguments):
    result = subprocess.run(['runuser', '-u', 'fasakha', '--', *arguments], cwd=root, capture_output=True)
    if result.returncode:
        raise RuntimeError('APPLICATION_COMMAND_FAILED: ' + pathlib.Path(arguments[0]).name)
    return result.stdout


BUNDLE_ROOT = pathlib.Path(__file__).resolve().parent
BUNDLE_MANIFEST = json.loads((BUNDLE_ROOT / 'manifest.json').read_text())

def source(root, revision, relative):
    versions = {BUNDLE_MANIFEST['release']: 'release', BUNDLE_MANIFEST['baseline']: 'baseline'}
    if revision not in versions:
        raise RuntimeError('BUNDLE_REVISION_MISMATCH')
    key = versions[revision] + '/' + relative
    if key not in BUNDLE_MANIFEST['blobs']:
        raise RuntimeError('BUNDLE_FILE_NOT_REVIEWED')
    path = BUNDLE_ROOT / key
    safe(path)
    data = path.read_bytes()
    if blob(data) != BUNDLE_MANIFEST['blobs'][key]:
        raise RuntimeError('BUNDLE_BLOB_MISMATCH: ' + relative)
    return data


def plan_target(root, release, relative, current):
    if relative not in PUBLISH_ORDER:
        raise RuntimeError('FILE_NOT_REVIEWED: ' + relative)
    reviewed = source(root, release, relative)
    if relative == ROBOTS:
        return robots_patch(current, reviewed)
    if relative == LOGIN:
        return login_patch(current, reviewed)
    if relative in NEW_FILES:
        if current is None or current == reviewed:
            return reviewed
        raise RuntimeError('NEW_FILE_CONFLICT: ' + relative)
    if current is None:
        raise RuntimeError('BASELINE_FILE_MISSING: ' + relative)
    if current == reviewed:
        return current
    return surgical_patch(current, source(root, BASELINES[relative], relative), reviewed, relative)


def install(root, release, check_only=False):
    if os.geteuid() != 0 or root != APP_ROOT or not re.fullmatch('[a-f0-9]{40}', release):
        raise RuntimeError('FIXED_ROOT_RELEASE_REQUIRED')
    user = pwd.getpwnam('fasakha')
    uid = user.pw_uid
    safe_directory(root, uid)
    if root.stat().st_uid != uid:
        raise RuntimeError('APPLICATION_OWNER_REQUIRED')
    if check_only:
        return _install_locked(root, release, True, uid, user.pw_gid)
    lock_path = root.parent / '.web-storefront-seo-update.lock'
    safe(lock_path)
    lock = os.open(lock_path, os.O_CREAT | os.O_RDWR | os.O_NOFOLLOW, 0o600)
    try:
        meta = os.fstat(lock)
        if not stat.S_ISREG(meta.st_mode) or meta.st_uid != 0 or meta.st_nlink != 1 or stat.S_IMODE(meta.st_mode) != 0o600:
            raise RuntimeError('UPDATE_LOCK_UNSAFE')
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        return _install_locked(root, release, False, uid, user.pw_gid)
    finally:
        os.close(lock)


def _install_locked(root, release, check_only, uid, gid):
    originals, targets = {}, {}
    if not NEW_FILES:
        raise RuntimeError('SEO_RELEASE_FILES_MISSING')
    for relative in PUBLISH_ORDER:
        safe_directory((root / relative).parent, uid)
        old = snapshot(root / relative, uid)
        targets[relative] = plan_target(root, release, relative, None if old is None else old['bytes'])
        originals[relative] = old
    # Lint final merged PHP without loading the application or writing caches.
    with tempfile.TemporaryDirectory(prefix='web-storefront-seo-lint-') as staged:
        os.chmod(staged, 0o755)
        for index, (relative, payload) in enumerate(targets.items()):
            if relative.endswith('.php'):
                candidate = pathlib.Path(staged) / (str(index) + '.php')
                candidate.write_bytes(payload)
                candidate.chmod(0o644)
                owned_command(root, [PHP, '-l', str(candidate)])
    if check_only:
        print(json.dumps({'status': 'WEB_STOREFRONT_SEO_PREFLIGHT_OK', 'files': len(targets), 'database_writes': 0}))
        return
    parent = root.parent / 'web-storefront-seo-backups'
    safe(parent)
    if parent.exists() and (not parent.is_dir() or parent.stat().st_uid != 0 or parent.stat().st_mode & 0o077):
        raise RuntimeError('BACKUP_PARENT_UNSAFE')
    parent.mkdir(mode=0o700, exist_ok=True)
    backup = pathlib.Path(tempfile.mkdtemp(prefix=release[:12] + '-', dir=parent))
    os.chmod(backup, 0o700)
    manifest = {'release': release, 'baselines': BASELINES, 'files': {},
                'target_blobs': {relative: blob(payload) for relative, payload in targets.items()}}
    for relative, old in originals.items():
        manifest['files'][relative] = None if old is None else {k: v for k, v in old.items() if k != 'bytes'}
        if old is not None:
            saved = backup / relative
            saved.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
            saved.write_bytes(old['bytes'])
            os.chmod(saved, 0o600)
    (backup / 'manifest.json').write_text(json.dumps(manifest, indent=2))
    os.chmod(backup / 'manifest.json', 0o600)
    written, created_directories = {}, []
    try:
        for relative, old in originals.items():
            if snapshot(root / relative, uid) != old:
                raise RuntimeError('CONCURRENT_EDIT: ' + relative)
        for relative in PUBLISH_ORDER:
            parent_path = (root / relative).parent
            missing = []
            while not parent_path.exists():
                safe(parent_path)
                missing.append(parent_path)
                parent_path = parent_path.parent
            for directory in reversed(missing):
                directory.mkdir(mode=0o755)
                os.chown(directory, uid, gid)
                created_directories.append(directory)
            old, payload = originals[relative], targets[relative]
            safe_directory((root / relative).parent, uid)
            if snapshot(root / relative, uid) != old:
                raise RuntimeError('CONCURRENT_EDIT: ' + relative)
            if old is None or old['bytes'] != payload:
                atomic(root / relative, payload, old['mode'] if old else 0o644,
                       old['uid'] if old else uid, old['gid'] if old else gid)
                written[relative] = snapshot(root / relative, uid)
        for relative, published in written.items():
            if snapshot(root / relative, uid) != published:
                raise RuntimeError('CONCURRENT_EDIT: ' + relative)
        for action in ('route:clear', 'view:clear'):
            owned_command(root, [PHP, str(root / 'artisan'), action])
        owned_command(root, [PHP, str(root / 'deployment/check_web_storefront_seo.php')])
        print(json.dumps({'status': 'WEB_STOREFRONT_SEO_READY', 'updated_files': len(written),
                          'backup': str(backup), 'release': release, 'database_writes': 0}))
    except BaseException:
        complete = True
        for relative, published in reversed(list(written.items())):
            try:
                if snapshot(root / relative, uid) != published:
                    complete = False
                    continue
                old = originals[relative]
                if old is None:
                    (root / relative).unlink()
                else:
                    atomic(root / relative, old['bytes'], old['mode'], old['uid'], old['gid'])
            except (OSError, RuntimeError):
                complete = False
        for directory in reversed(created_directories):
            try:
                directory.rmdir()
            except OSError:
                pass
        for action in ('route:clear', 'view:clear'):
            try:
                owned_command(root, [PHP, str(root / 'artisan'), action])
            except RuntimeError:
                complete = False
        print('WEB_STOREFRONT_SEO_ROLLBACK_' + ('RESTORED' if complete else 'NEEDS_REVIEW'))
        raise


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', required=True)
    parser.add_argument('--release', required=True)
    parser.add_argument('--check', action='store_true', help='Read-only source, permission and merge preflight')
    args = parser.parse_args()
    try:
        install(pathlib.Path(args.root).absolute(), args.release, args.check)
    except Exception as error:
        print(str(error))
        raise SystemExit(1)
