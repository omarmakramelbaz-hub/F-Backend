#!/usr/bin/env bash
set -euo pipefail
seo_bundle="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
python3 "$seo_bundle/install.py" --root /home/fasakha/public_html --release 2ec847b6c58575bf56677094a5964a96e168149a "$@"
