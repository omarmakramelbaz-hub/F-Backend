<!doctype html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <title>فسخانستا | طعم اللمة الحلوة — اطلب أونلاين</title>
    <meta name="description" content="اختار الفسيخ والرنجة والبطارخ من مينيو فرع فسخانستا الأقرب ليك. اعرف إجمالي طلبك والتوصيل وأكد طلبك مباشرة من الموقع.">
    <meta name="theme-color" content="#091320">
    <meta property="og:title" content="فسخانستا — طعم اللمة الحلوة">
    <meta property="og:description" content="مينيو متجرك، سلتك، وطلبك لحد باب البيت.">
    <meta property="og:image" content="{{ asset('storefront/hero.webp') }}">
    <link rel="icon" href="{{ asset('dashboard/branding/fasakhansta-logo-transparent.png') }}?v=20261017-3" type="image/png" sizes="any">
    <link rel="apple-touch-icon" href="{{ asset('dashboard/branding/fasakhansta-logo-transparent.png') }}?v=20261017-3">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Tajawal:wght@400;500;600;700;800;900&display=swap" rel="stylesheet">
    <link rel="preload" as="image" href="{{ asset('storefront/hero.webp') }}">
    <link rel="stylesheet" href="{{ asset('dashboard/vendor/leaflet/leaflet.css') }}">
    <link rel="stylesheet" href="{{ asset('storefront/storefront.css') }}?v=20261017-3">
    <script id="storefront-data" type="application/json">{!! json_encode(['branches'=>$storefrontBranches,'info'=>$storefrontInfo,'endpoints'=>['branches'=>route('storefront.branches'),'catalog'=>route('storefront.catalog'),'addresses'=>route('storefront.addresses'),'quote'=>route('storefront.quote'),'checkout'=>route('storefront.checkout')]], JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_AMP | JSON_HEX_QUOT | JSON_UNESCAPED_UNICODE) !!}</script>
    <script src="{{ asset('dashboard/vendor/leaflet/leaflet.js') }}" defer></script>
    <script src="{{ asset('storefront/storefront.js') }}?v=20261017-3" defer></script>
</head>
<body>
<a class="skip-link" href="#menu">انتقل للمينيو</a>
<div class="announcement"><span>من قلب مصر، على سفرتك.</span><span>اطلب من الموقع مباشرة <span aria-hidden="true">↙</span></span></div>
<header class="site-header">
    <a href="#" class="brand" aria-label="فسخانستا الرئيسية"><img src="{{ asset('dashboard/branding/fasakhansta-logo-transparent.png') }}" alt="" width="58" height="58"><span>فسخانستا<small>FASAKHANSTA</small></span></a>
    <nav aria-label="القائمة الرئيسية"><a class="active" href="#menu">المنيو</a><a href="#story">حكايتنا</a><a href="#branches">المتاجر</a><a href="#app">التطبيق</a></nav>
    <div class="header-actions"><button class="branch-shortcut" data-action="choose-branch"><span aria-hidden="true">⌖</span><span id="header-branch">حدد عنوانك</span></button><button class="cart-trigger" data-action="cart" aria-label="افتح سلة الطلب"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" aria-hidden="true"><path d="M5 7h14l1 14H4L5 7Z M8 8V6a4 4 0 0 1 8 0v2"/></svg><span class="cart-label">سلة الطلب</span><b id="cart-count">0</b></button></div>
</header>
<main>
    <section class="hero" aria-labelledby="hero-title">
        <div class="hero-copy"><span class="eyebrow"><i></i> للناس اللي فاهمة في الأكلة الحلوة</span><h1 id="hero-title">اللمة الحلوة،<br>تبدأ بـ <em>فسخانستا.</em></h1><p>فسيخ، رنجة، وبطارخ… كل اللي بتحبه على سفرة واحدة.<br class="desktop-only"> اختار مزاجك من منيو متجرك، وإحنا نوصّله لحد عندك.</p><div class="hero-actions"><a class="button primary" href="#menu">اطلب اللي على مزاجك <span aria-hidden="true">↙</span></a><a class="text-link" href="#delivery">حدد مكان التوصيل <span aria-hidden="true">←</span></a></div><div class="hero-assurance"><span><b aria-hidden="true">✓</b> طلب مباشر من المتجر</span><span><b aria-hidden="true">✓</b> كاش عند الاستلام</span></div></div>
        <div class="hero-art"><img class="hero-photo" src="{{ asset('storefront/hero.webp') }}" alt="سفرة فسيخ ورنجة مع الليمون والبصل والخبز" width="1254" height="1254" fetchpriority="high"><div class="hero-stamp" aria-hidden="true">أصول الأكلة<br><strong>المصرية</strong><span>FASAKHANSTA</span></div><div class="hero-caption"><span class="caption-line"></span><span>طعم له ناسه.<small>ولمة ليها أصولها.</small></span></div><small class="image-note">صورة تقديمية</small></div>
    </section>
    <div class="flavor-strip" aria-hidden="true"><span>فسيخ مظبوط</span><i>✦</i><span>رنجة على أصولها</span><i>✦</i><span>بطارخ ومزاج</span><i>✦</i><span>لمة مصرية</span><i>✦</i><span>فسخانستا</span></div>
    <section id="delivery" class="delivery-section section-wrap" aria-labelledby="delivery-title">
        <div class="delivery-card">
            <div class="delivery-intro"><span class="eyebrow">اللمة تبدأ من عنوانك</span><h2 id="delivery-title">نوصّل لك فين؟</h2><p>حدد موقعك واكتب عنوانك ورقمك، علشان نعرض لك أقرب متاجر فسخانستا اللي بتخدم مكانك.</p><div class="delivery-steps"><span><b>١</b> حدد موقعك</span><span><b>٢</b> اختار متجرك</span><span><b>٣</b> جهّز طلبك</span></div></div>
            <form id="delivery-form" class="delivery-form">
                <div class="checkout-fields">
                    <label class="full">رقم الموبايل<input name="customer_phone" type="tel" autocomplete="tel" inputmode="tel" dir="ltr" required maxlength="30" placeholder="01xxxxxxxxx"></label>
                    <label class="full">المنطقة أو أقرب معلم<input name="area" autocomplete="address-level2" required minlength="2" maxlength="150" placeholder="ابحث عن منطقتك أو مكان قريب"><span id="address-suggestions" class="address-suggestions"></span></label>
                    <label class="full">عنوان التوصيل بالتفصيل<input name="address" autocomplete="street-address" required minlength="8" maxlength="500" placeholder="الشارع، رقم العمارة، الدور والشقة"></label>
                </div>
                <div class="location-heading"><strong>ثبت الدبوس عند مدخل العمارة</strong><button type="button" class="text-link" id="geolocate">⌖ استخدم موقعي الحالي</button></div>
                <div id="delivery-map" class="delivery-map" aria-label="خريطة تحديد عنوان التوصيل"></div>
                <p id="location-help" class="muted">استخدم موقعي، أو ابحث عن المنطقة واضغط على الخريطة لتحديد مكان التوصيل.</p>
                <label class="confirm-location"><input name="location_confirmed" type="checkbox" required> الدبوس في مكان التوصيل الصحيح</label>
                <p class="privacy-note">بنستخدم عنوانك ورقمك لتحديد الخدمة وتجهيز طلبك والتواصل معاك بخصوصه.</p>
                <div id="delivery-error" class="form-error" role="alert"></div>
                <button id="find-stores" type="submit" class="button primary wide">اعرض المتاجر اللي بتخدمني <span aria-hidden="true">←</span></button>
            </form>
            <div id="delivery-summary" class="delivery-summary" hidden><span class="delivery-summary-icon" aria-hidden="true">⌖</span><div><strong>عنوان التوصيل</strong><p id="delivery-address"></p><span id="delivery-phone" dir="ltr"></span></div><button type="button" class="button secondary" data-action="edit-location">تغيير العنوان أو الموقع</button></div>
        </div>
    </section>
    <section id="menu" class="menu-section section-wrap" aria-labelledby="menu-title">
        <div class="section-top"><div><span class="eyebrow">كل مزاج وليه اختياره</span><h2 id="menu-title">المنيو اللي يجمعنا.</h2></div><label class="branch-picker"><span>المتاجر اللي بتخدم عنوانك</span><select id="branch-select" aria-label="اختر المتجر أو الفرع" disabled><option value="">حدد عنوانك الأول</option></select></label></div>
        <div class="menu-tools"><div id="categories" class="categories" aria-label="أقسام المنيو"></div><label class="search"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" aria-hidden="true"><circle cx="10.5" cy="10.5" r="6.5"/><path d="m16 16 5 5"/></svg><input id="search" type="search" placeholder="بتدور على إيه؟" aria-label="ابحث عن منتج"></label></div>
        <div id="menu-status" class="menu-status" role="status"><span class="empty-symbol" aria-hidden="true">⌖</span><h3>حدد مكان التوصيل الأول</h3><p>بعد تأكيد موقعك وعنوانك ورقمك، هتظهر المتاجر اللي تقدر تخدمك.</p><a class="button secondary" href="#delivery">حدد عنوانك ←</a></div>
        <div id="product-grid" class="product-grid"></div>
        <button id="show-more" class="button secondary show-more" hidden>عرض أصناف أكتر</button>
        <p class="menu-footnote">الأسعار بالجنيه المصري. التوصيل وأي ضريبة مطبقة بيظهروا بالتفصيل قبل تأكيد الطلب.</p>
    </section>
    <section id="story" class="story section-wrap"><div class="story-mark"><span>أكلة مصرية.</span><strong>بمزاج<br>فسخانستا.</strong><span class="story-sign">طعم له ناسه ↙</span></div><div class="story-copy"><span class="eyebrow">حكايتنا في كل لقمة</span><h2>في أكلات بتتاكل،<br>وأكلات بتعمل لمة.</h2><p>الفسيخ والرنجة ليهم مكانهم على سفرتنا؛ يوم إجازة، عزومة صحاب، أو أكلة نفسك فيها. في فسخانستا بتلاقي اختياراتك من الأسماك المملحة والمدخنة، وتطلبها بالطريقة اللي تناسبك.</p><a href="#menu" class="text-link">جهّز اللمة، واختار أكلتك <span aria-hidden="true">←</span></a></div></section>
    <section class="how-it-works section-wrap"><div><span class="eyebrow">من المينيو لحد بابك</span><h2>طلبك في ٣ خطوات.</h2></div><ol><li><b>01</b><h3>حدد عنوانك ومتجرك</h3><p>شوف المتاجر اللي بتغطي موقعك واختار الأقرب.</p></li><li><b>02</b><h3>ظبّط طلبك</h3><p>اختار المنتجات والكميات والإضافات.</p></li><li><b>03</b><h3>أكد العنوان والطلب</h3><p>راجع الإجمالي والتوصيل وادفع عند الاستلام.</p></li></ol></section>
    <section id="branches" class="branches-section section-wrap"><div class="section-top"><div><span class="eyebrow">فسخانستا أقرب ليك</span><h2>المتاجر اللي بتخدم عنوانك.</h2></div><span class="muted">حسب نطاقات التوصيل المسجلة في التطبيق</span></div><div class="store-tools" id="store-tools" hidden><div class="store-filters" aria-label="تصنيف المتاجر"><button class="store-filter active" data-action="store-filter" data-filter="all" aria-pressed="true">كل المتاجر</button><button class="store-filter" data-action="store-filter" data-filter="branches" aria-pressed="false">فروع فسخانستا</button><button class="store-filter" data-action="store-filter" data-filter="stores" aria-pressed="false">متاجر المناطق</button></div><label class="search store-search"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" aria-hidden="true"><circle cx="10.5" cy="10.5" r="6.5"/><path d="m16 16 5 5"/></svg><input id="store-search" type="search" placeholder="اسم المتجر أو المنطقة" aria-label="ابحث عن متجر أو منطقة"></label></div><p id="store-count" class="store-count" role="status"></p><div id="branch-cards" class="branch-cards"></div><button id="show-more-stores" class="button secondary store-show-more" hidden>عرض متاجر أكتر</button></section>
    <section id="ordering-faq" class="faq-section section-wrap"><div><span class="eyebrow">كل حاجة قبل ما تطلب</span><h2>أسئلة على السفرة.</h2></div><div><details><summary>هل لازم أحمل التطبيق علشان أطلب؟</summary><p>تقدر تختار المنتجات وتأكد طلبك من الموقع مباشرة، من الموبايل أو الكمبيوتر.</p></details><details><summary>إزاي أعرف المتاجر اللي بتوصل لي؟</summary><p>حدد دبوس التوصيل واكتب عنوانك ورقمك. هتظهر لك المتاجر اللي بتغطي مكانك بنفس نطاقات الخدمة في التطبيق، وتعرف تكلفة التوصيل قبل تأكيد الطلب.</p></details><details><summary>إيه طريقة الدفع المتاحة؟</summary><p>الدفع كاش عند استلام الطلب. تسجيل الطلب على الموقع لا يعني تحصيل قيمته.</p></details><details><summary>عايز أعدل طلب أكدته، أعمل إيه؟</summary><p>تواصل مع المتجر من الرقم الموضح في قسم المتاجر والفروع، واذكر رقم طلبك لمراجعة التعديل حسب حالة التجهيز.</p></details></div></section>
    <section id="app" class="app-section section-wrap"><div><span class="eyebrow">فسخانستا في جيبك</span><h2>تحب تطلب من التطبيق؟</h2><p>نفس اللمة، من الموبايل. تقدر كمان تطلب مباشرة من الموقع.</p></div><div class="app-downloads"><a class="button light" href="https://apps.apple.com/us/app/fasakhaninja/id6741027064" target="_blank" rel="noopener">App Store <span aria-hidden="true">↗</span></a><a class="button light" href="https://play.google.com/store/apps/details?id=com.smartvision.faskhanista" target="_blank" rel="noopener">Google Play <span aria-hidden="true">↗</span></a></div></section>
</main>
<footer><div class="footer-main section-wrap"><a href="#" class="brand"><img src="{{ asset('dashboard/branding/fasakhansta-logo-transparent.png') }}" alt="" width="58" height="58"><span>فسخانستا<small>FASAKHANSTA</small></span></a><p>طعم له ناسه. ولمة ليها أصولها.</p><div>@if(!empty($storefrontInfo['phone']))<a href="tel:{{ preg_replace('/[^+0-9]/','',$storefrontInfo['phone']) }}">تواصل معانا</a>@else<a href="#branches">المتاجر</a>@endif<a href="#ordering-faq">الطلب والتوصيل</a>@if(!empty($storefrontInfo['terms']))<button class="footer-link" data-action="terms">الشروط والأحكام</button>@endif @if(!empty($storefrontInfo['policy']))<button class="footer-link" data-action="policy">الخصوصية</button>@endif</div></div><div class="footer-bottom section-wrap"><span>© {{ date('Y') }} فسخانستا. جميع الحقوق محفوظة.</span><span>صُنع للّمة المصرية <span aria-hidden="true">✦</span></span></div></footer>
<button class="mobile-cart" id="mobile-cart" data-action="cart" hidden><span>عرض السلة <b id="mobile-count">0</b></span><strong id="mobile-total"></strong><span aria-hidden="true">←</span></button>
<dialog id="product-dialog" class="product-dialog" aria-labelledby="product-title"><button class="close-dialog" data-close aria-label="إغلاق">×</button><div id="product-detail"></div></dialog>
<dialog id="cart-dialog" class="cart-dialog" aria-labelledby="cart-title"><header class="dialog-heading"><div><span class="eyebrow">اللمة بتبدأ من هنا</span><h2 id="cart-title">سلة طلبك.</h2></div><button class="close-dialog" data-close aria-label="إغلاق السلة">×</button></header><div id="cart-content"></div><div id="cart-footer"></div></dialog>
<dialog id="checkout-dialog" class="checkout-dialog" aria-labelledby="checkout-title"><header class="dialog-heading"><div><span class="eyebrow">فاضل خطوة على الأكلة الحلوة</span><h2 id="checkout-title">بيانات التوصيل.</h2></div><button class="close-dialog" data-close aria-label="إغلاق">×</button></header><form id="checkout-form"><div class="checkout-fields"><label>اسمك<input name="customer_name" autocomplete="name" required minlength="2" maxlength="100" placeholder="الاسم بالكامل"></label><label>رقم الموبايل<input name="customer_phone" type="tel" dir="ltr" readonly required></label><label class="full">عنوان التوصيل<input name="address" readonly required></label><label class="full">المنطقة<input name="area" readonly required></label></div><div class="checkout-location-note"><span>✓ هنوصّل لنفس العنوان والموقع اللي حددتهم.</span><button type="button" class="text-link" data-action="edit-location">تغيير مكان التوصيل</button></div><label class="notes-label">ملاحظات للمتجر <span class="muted">(اختياري)</span><textarea name="notes" rows="2" maxlength="350" placeholder="أي تفاصيل تحب تقولها للمتجر؟"></textarea></label><p class="privacy-note">بياناتك بتتسجل مع الطلب لتجهيزه والتواصل معاك بخصوصه.</p><div class="form-error" id="checkout-error" role="alert"></div><button type="submit" id="review-order" class="button primary wide">مراجعة الإجمالي والتوصيل <span aria-hidden="true">←</span></button></form><div id="review-panel" hidden></div></dialog>
<dialog id="change-location-dialog" class="confirm-dialog" aria-labelledby="location-confirm-title"><h2 id="location-confirm-title">تغيّر مكان التوصيل؟</h2><p>هنراجع المتاجر اللي بتخدم العنوان الجديد. تغيير الموقع هيبدأ سلة جديدة.</p><div class="confirm-actions"><button class="button primary" id="confirm-location-change">غيّر مكان التوصيل</button><button class="button secondary" data-close>احتفظ بطلبي</button></div></dialog>
<dialog id="confirm-branch-dialog" class="confirm-dialog" aria-labelledby="branch-confirm-title"><h2 id="branch-confirm-title">تغيّر الفرع؟</h2><p>كل فرع ليه منيو وأسعار خاصة. تغيير الفرع هيبدأ سلة جديدة.</p><div class="confirm-actions"><button class="button primary" id="confirm-branch">غيّر الفرع</button><button class="button secondary" data-close>احتفظ بالسلة</button></div></dialog>
<dialog id="legal-dialog" class="checkout-dialog" aria-labelledby="legal-title"><header class="dialog-heading"><h2 id="legal-title"></h2><button class="close-dialog" data-close aria-label="إغلاق">×</button></header><div id="legal-content" class="legal-content"></div></dialog>
<div class="toast" id="toast" role="status" hidden></div>
<noscript><p class="noscript">فعّل JavaScript علشان تقدر تعرض المينيو وتطلب من الموقع.</p></noscript>
</body>
</html>
