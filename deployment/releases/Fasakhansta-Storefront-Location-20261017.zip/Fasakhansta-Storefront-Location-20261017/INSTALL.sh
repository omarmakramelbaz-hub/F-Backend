#!/usr/bin/env bash
set -euo pipefail
storefront_bundle="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
python3 "$storefront_bundle/install.py" --root /home/fasakha/public_html --release 01b8805ef49cc05c315edbde7909ad6489954190 "$@"
