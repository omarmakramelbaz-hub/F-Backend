#!/usr/bin/env bash
set -euo pipefail
seo_bundle="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
python3 "$seo_bundle/install.py" --root /home/fasakha/public_html --release c4a3a119e0a232a198c0633bd9aedf3547ee1d57 "$@"
