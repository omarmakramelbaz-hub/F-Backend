#!/usr/bin/env bash
set -euo pipefail
umask 077
customer_bundle="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
python3 "$customer_bundle/install.py" --root /home/fasakha/public_html --release 2c597530e88c78e39f54bc68351246732a566fa2 "$@"
